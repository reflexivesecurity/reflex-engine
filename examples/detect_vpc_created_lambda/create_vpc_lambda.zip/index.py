
def lambda_handler(event, context):
    print(event)
